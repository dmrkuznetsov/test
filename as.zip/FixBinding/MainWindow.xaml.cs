﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;

namespace FixBindingsSample {
    public partial class MainWindow : Window {
        public MainWindow() {
            InitializeComponent();
            var vm = (MainViewModelProxy)DataContext;
            vm.OriginalVm = new MainViewModel();
        }
    }
    public class MainViewModel {
        public string Property { get; set; }
        public ObservableCollection<Item> Items { get; }
        public MainViewModel() {
            Items = new ObservableCollection<Item>();
            for (int i = 0; i < 100; i++)
                Items.Add(new Item { Id = i, Name = string.Format("Name_{0}", i) });
            Property = "Works";
        }
    }
    public class Item {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    public class MainViewModelProxy : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void RaisePropertyChanged([CallerMemberName] string memberName ="")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(memberName));
        }
        private MainViewModel _originalVm;
        public MainViewModel OriginalVm
        {
            set
            {
                _originalVm = value;
                RaisePropertyChanged(nameof(Property));
                RaisePropertyChanged(nameof(Items));
            }
        }
        public ObservableCollection<Item> Items => _originalVm?.Items;

        public string Property 
        {
            get=> _originalVm?.Property;
            set
            {
                if (_originalVm != null)
                {
                    _originalVm.Property = value;
                    RaisePropertyChanged();
                }
            }
        }
    }
}