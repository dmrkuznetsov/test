﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace TestSamples {
    // Реализуйте интерфейс INotifyPropertyChanged,
    // чтобы к свойствам Employee можно было привязываться.
    // Реализация свойств должна быть максимально короткой.
    public class Employee : INotifyPropertyChanged {

        public event PropertyChangedEventHandler PropertyChanged;

        public void RaisePropertyChanged([CallerMemberName] string memberName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(memberName));
        }

        private string _firstName;
        public string FirstName
        {
            get => _firstName;
            set
            {
                if(_firstName != value)
                {
                    _firstName = value;
                    RaisePropertyChanged();
                    RaisePropertyChanged(nameof(FullName));
                }
            }
        }
        private string _lastName;
        public string LastName 
        {
            get => _lastName;
            set
            {
                if (_lastName != value)
                {
                    _lastName = value;
                    RaisePropertyChanged();
                    RaisePropertyChanged(nameof(FullName));
                }
            }
        }
        public string FullName => FirstName + LastName;
        private int _age;
        public int Age 
        { 
            get => _age;
            set
            {
                if (_age != value)
                {
                    _age = value;
                    RaisePropertyChanged();
                }
            }
        }
    }
}