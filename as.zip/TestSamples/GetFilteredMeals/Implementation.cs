﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TestSamples {
    public class Group {
        public string Name { get; set; }
        public IEnumerable<Meal> Meals { get; set; }
    }
    public class Meal {
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
    public static class Helper {
        // Без использования LINQ реализуйте метод GetFilteredMeals, возвращающий IEnumerable<Meal>,
        // где Meal.Price выше или равна minPrice
        public static IEnumerable<Meal> GetFilteredMeals(IEnumerable<Group> categories, decimal minPrice) {
            foreach (var gr in categories)
            {
                if (gr is null)
                    continue;
                if (gr.Meals is null)
                    continue;
                foreach (var m in gr.Meals)
                {
                    if (m.Price >= minPrice)
                    {
                        yield return m;
                    }
                }
            }
        }
        // То же самое, но с использованием LINQ
        public static IEnumerable<Meal> GetFilteredMealsLINQ(IEnumerable<Group> categories, decimal minPrice) {

            return categories.Where(x=>x != null && x.Meals != null).SelectMany(x => x.Meals).Where(x => x.Price >= minPrice);
        }
        // Переработайте метод GetFilteredMeals так, чтобы в нем можно было использовать любое условие
        public static IEnumerable<Meal> GetFilteredMealsLINQ(IEnumerable<Group> categories, Func<Meal, bool> condition) {
            return categories.Where(x=>x != null && x.Meals != null).SelectMany(x => x.Meals).Where(condition);
        }
    }
}